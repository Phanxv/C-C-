#include <iostream>
#include <cstring>
#include <cstdlib>
#include <time.h>

using namespace std;

class Card
{
    public :
        void assignCardFace(char cardFace) {face = cardFace;}
        void assignCardNumber(int cardNumber) {number = cardNumber;}
        char getCardFace() {return face;}
        int getCardNumber() {return number;}
    private :
        char face;
        int number;
};

class Deck
{
    public :
        Deck() : numberOfCard(0) {} //default constructor deck
        void starterDeck(); //52 cards
        void shuffleCards();
        void showDeck(); //show every cards in Deck
        void showCard(int); //(use with showDeck();) input index of card output num&face
        void showSingleCard(int i) {showCard(i-1);} //show a card which has index i-1 **
        void testDeck(); //Sample Deck has 5 cards
        void swapCard(int,int); //swap card in the same Deck **
        Card sendCard(int); //send a Card from Deck 1 to Deck 2 **
	    void placeAfter(Card); //place a Card after Deck **
        void placeBefore(Card); //place a Card before Deck **
        void dealCard(int, int, Deck *); // dealing cards to players hand **
    private :
        int numberOfCard;
        Card deckCard[52];
};

//main
int main()
{
    /*Deck FirstDeck;
    FirstDeck.starterDeck();
    cout << "Deck before shuffle" << endl << endl;
    FirstDeck.showDeck();
    FirstDeck.shuffleCards();
    cout << "Deck after shuffle" << endl << endl;
    FirstDeck.showDeck();*/
    /*Deck testDeck, testDeck2;
    testDeck.testDeck();
    cout << "Test deck" << endl;
    testDeck.showDeck();
    cout << "Test deck after swap card number 1 and card number 4" << endl;
    testDeck.swapCard(1,4);
    testDeck.showDeck();
    cout << "Show card number 3 from test deck" << endl;
    testDeck.showSingleCard(3);
    cout << "Give the last card of testDeck to testDeck2" << endl;
    //testDeck2.testDeck();
    testDeck2.placeAfter(testDeck.sendCard(1));
    cout << "TestDeck after sendCard" << endl;
    testDeck.showDeck();
    cout << "TestDeck2 after placeCard" << endl;
    testDeck2.showDeck();*/

    //driver program

    Deck TestStack;
    Deck Player[2];

    TestStack.testDeck();
    cout << "Sample Deck" << endl;
    TestStack.showDeck();


    cout << "Show card(3) from Test Stack" << endl;
    TestStack.showSingleCard(3);
    cout << endl;
    cout << "Shuffled Full stack before deal card" << endl;
    TestStack.shuffleCards();
    TestStack.showDeck();

    cout << "Test deck after swap card (1) and card (4)" << endl;
    TestStack.swapCard(1,4);
    TestStack.showDeck();

    cout << "Player 1 hand before deal card" << endl;
    Player[0].showDeck();
    cout << "Player 2 hand before deal card" << endl;
    Player[1].showDeck();
    TestStack.dealCard(2,2,Player);
    cout << "Full stack after deal card" << endl;
    TestStack.showDeck();
    cout << "Player 1 hand after deal card" << endl;
    Player[0].showDeck();
    cout << "Player 2 hand after deal card" << endl;
    Player[1].showDeck();
    Player[0].placeAfter(Player[1].sendCard(2));
    cout << "---> Give card(2) from P.2 to P.1 <---" << endl << endl;
    cout << "Card on hand Player 1" << endl;
    Player[0].showDeck();
    cout << "Card on hand Player 2" << endl;
    Player[1].showDeck();
    cout << "---> Give card(1) from P.1 to P.2 <---" << endl << endl;
    Player[1].placeBefore(Player[0].sendCard(1));
    cout << "Card on hand Player 1" << endl;
    Player[0].showDeck();
    cout << "Card on hand Player 2" << endl;
    Player[1].showDeck();

}

void Deck::starterDeck()
{
    for(int i=0;i<52;i++)
    {
        if(i<=12)
        {
            deckCard[i].assignCardFace('C');
            deckCard[i].assignCardNumber(i+1);
        }
        else if(i<=25)
        {
            deckCard[i].assignCardFace('D');
            deckCard[i].assignCardNumber(i-12);
        }
        else if(i<=38)
        {
            deckCard[i].assignCardFace('H');
            deckCard[i].assignCardNumber(i-25);
        }
        else
        {
            deckCard[i].assignCardFace('S');
            deckCard[i].assignCardNumber(i-38);
        }
        numberOfCard++;
    }
}

void Deck::showDeck()
{
    if(numberOfCard == 0)
        cout << "There is no card on this deck" << endl;
    else
    {
        for(int i=0;i<numberOfCard;i++)
            showCard(i);
    }
    cout << endl;
}

void Deck::shuffleCards()
{
    int randomIndex;
    Card tempCard;
    srand(time(NULL));
    for(int i=0;i<numberOfCard;i++)
    {
        randomIndex = rand()%numberOfCard;
        tempCard = deckCard[randomIndex];
        deckCard[randomIndex] = deckCard[i];
        deckCard[i] = tempCard;
    }
}

void Deck::showCard(int i)
{
    if(deckCard[i].getCardNumber() == 1)
        cout << "[" << deckCard[i].getCardFace() << "-" << "A" << "]" << endl;
    else if(deckCard[i].getCardNumber() <= 10)
        cout << "[" << deckCard[i].getCardFace() << "-" << deckCard[i].getCardNumber() << "]" << endl;
    else if(deckCard[i].getCardNumber() == 11)
        cout << "[" << deckCard[i].getCardFace() << "-" << "J" << "]" << endl;
    else if(deckCard[i].getCardNumber() == 12)
        cout << "[" << deckCard[i].getCardFace() << "-" << "Q" << "]" << endl;
    else if(deckCard[i].getCardNumber() == 13)
        cout << "[" << deckCard[i].getCardFace() << "-" << "K" << "]" << endl;
}

void Deck::testDeck()
{
    numberOfCard = 5;
    deckCard[0].assignCardFace('C');
    deckCard[0].assignCardNumber(1);
    deckCard[1].assignCardFace('C');
    deckCard[1].assignCardNumber(5);
    deckCard[2].assignCardFace('H');
    deckCard[2].assignCardNumber(3);
    deckCard[3].assignCardFace('S');
    deckCard[3].assignCardNumber(2);
    deckCard[4].assignCardFace('D');
    deckCard[4].assignCardNumber(12);
}

//swap card in the same Deck
void Deck::swapCard(int a, int b)
{
    Card tempCard;
    tempCard = deckCard[a-1];
    deckCard[a-1] = deckCard[b-1];
    deckCard[b-1] = tempCard;
}

Card Deck::sendCard(int index)  // pass a Card from Deck 1 to Deck 2
{
    Card tempCard = deckCard[index-1];
    for(int i = index-1; i < numberOfCard ;i++)
    {
        deckCard[i] = deckCard[i+1];           //decreasing index of Cards which below 'Sent Card'
    }
    numberOfCard--;        // amount of left cards in Deck 1
    return tempCard;
}

void Deck::placeAfter(Card a)  //place (Card a) on bottom of Recived Deck
{
    deckCard[numberOfCard] = a; //set Index be 'numberOfCard' of Recived Deck
    numberOfCard++;
}

void Deck::placeBefore(Card a)
{
    // assume numberOfCard = 5
    for(int i = numberOfCard; i > 0; i--)
    {
        deckCard[i] = deckCard[i-1];//make card index(4) to be card index (5)
    }
    deckCard[0] = a; //place (Card a) on top of another Deck
    numberOfCard++;
}


void Deck::dealCard(int amountDeal, int numberOfPlayer, Deck *reciever) //pointer to array
{
    cout << "........ Dealing Cards ........" << endl;
    cout << numberOfCard << endl;
    for(int i = 0; i < amountDeal; i++) // Amount of cards on players hand
    {
        for(int j = 0; j < numberOfPlayer; j++) //giving one by one
        {
            reciever[j].placeAfter(sendCard(numberOfCard));
        }
    }
}

//ไพ่ 1 ใบเสียบลงตำแหน่งที่ต้องการในมือ //ระบุตำแหน่งที่ต้องการ  dealBetween //placeCard
// หยิบไพ่ที่ติดกันออกมาเป็น 1 กองใหม่  //sendCard = จำนวนไพ่  -> placeBefore ลงnew deck
//วางกองไพ่ที่หยิบออกมาแบบเลือกตำแหน่งได้
//graphic gui

